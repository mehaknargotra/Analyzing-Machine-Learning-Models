#!/usr/bin/env python
# coding: utf-8

# # Using information gain

# In[1]:


def select_random_attributes(n_feats):
    m = int(np.sqrt(n_feats))
    selected_feats = np.random.choice(n_feats, m, replace=False)
    return selected_feats


# In[2]:


import pandas as pd
import numpy as np
from collections import Counter

class Node:
    def __init__(self, feature=None, threshold=None, left=None, right=None, *, value=None):
        self.feature = feature
        self.threshold = threshold
        self.left = left
        self.right = right
        self.value = value

    def is_leaf_node(self):
        return self.value is not None


# In[3]:


class DecisionTree:
    def __init__(self, min_samples_split=10, max_depth=16, n_features=None):
        self.min_samples_split = min_samples_split
        self.max_depth = max_depth
        self.n_features = n_features
        self.root = None

    def fit(self, X, y):
        # Checking for NaN values
        if np.isnan(X).any():
            # by replacing them with mean values
            X = np.nan_to_num(X, nan=np.nanmean(X))
#         number of features set to minimum number of features when specified
        self.n_features = X.shape[1] if not self.n_features else min(X.shape[1], self.n_features)
        self.root = self._grow_tree(X, y)

    def _grow_tree(self, X, y, depth=0, used_features=None):
        n_samples, n_feats = X.shape
        #calculating the number of unique labels in y
        n_labels = len(set(y)) 
        #this is stopping criteria check
        #we'll check if the n0. of samples is lesser than the minimum number needed 
        #if depth is greater than max depth that is set to 100
        # or if leaf node (pure)
        if (depth >= self.max_depth or n_labels == 1 or n_samples < self.min_samples_split):
            leaf_value = self._most_common_label(y)
            return Node(value=leaf_value)

        #chooses randomly random subset of features (from features chosen in the very first function that returns n_feats) 
        #selects which to use to split node
        feat_idxs = self._random_features(n_feats)
        #best spli which makes use of info gain
        best_feature, best_thresh = self._best_split(X, y, feat_idxs)
        #This line will split the data into left and right subsets based on the above line 
        #It returns the indexes of samples that belong to the left and right child nodes
        left_idxs, right_idxs = self._split(X[:, best_feature], best_thresh)

        #it is possible that when we split a node, its left or right side is empty. in such cases
        #it will create a child with the most common label and return it
        if len(left_idxs) == 0 or len(right_idxs) == 0:
            leaf_value = self._most_common_label(y)
            return Node(value=leaf_value)

        #didnt want the node to keep splitting on the same attribute again n again 
        #this is new from the previous decision tree implementation
        #basically, if the node splits on weather, at rainy and sunny, then i do not want the node below rainy to split on rainy again.
        left_used_features = set(used_features) if used_features is not None else set()
        right_used_features = set(used_features) if used_features is not None else set()
        left_used_features.add(best_feature)
        right_used_features.add(best_feature)

        left = self._grow_tree(X[left_idxs, :], y[left_idxs], depth + 1, left_used_features)
        right = self._grow_tree(X[right_idxs, :], y[right_idxs], depth + 1, right_used_features)
        return Node(best_feature, best_thresh, left, right)



    def _random_features(self, n_feats):
        if self.n_features is None:
            return np.arange(n_feats) #all features in n_feats are considered for splitting
        else:
            return np.random.choice(n_feats, self.n_features, replace=False) #not all, randomly chooses features from n_feats for being considered for split.
    
    def _best_split(self, X, y, feat_idxs):
        best_gain = -1
        split_idx, split_threshold = None, None

        for feat_idx in feat_idxs:
            X_column = X[:, feat_idx] #whatever the current feature is we will take that feature's column and assignn to X_column
            thresholds = np.unique(X_column) #self explaintory
            #For each threshold, it will calculate the info gain
            #by splitting the data based on the current feature and thr using the below method
            #If the calculated gain is greater than the current best_gain, it updates stuff
            for thr in thresholds:
                gain = self._information_gain(y, X_column, thr)

                if gain > best_gain:
                    best_gain = gain
                    split_idx = feat_idx
                    split_threshold = thr

        return split_idx, split_threshold

    def _information_gain(self, y, X_column, threshold):
        parent_entropy = self._entropy(y)
         # create children
        left_idxs, right_idxs = self._split(X_column, threshold)

        if len(left_idxs) == 0 or len(right_idxs) == 0:
            return 0
        
        # calculating the weighted avg entropy of children #need to measure impurity at each split
        n = len(y)
        n_l, n_r = len(left_idxs), len(right_idxs)
        #all these calcs for info gain
        e_l = self._entropy(y[left_idxs])
        e_r = self._entropy(y[right_idxs])
        child_entropy = (n_l / n) * e_l + (n_r / n) * e_r
        # calculate the IG
        information_gain = parent_entropy - child_entropy

        if parent_entropy == 0:
            return 0

        return information_gain if not np.isnan(information_gain) else 0

    def _split(self, X_column, split_thresh):
        left_idxs = np.where(X_column <= split_thresh)[0]
        right_idxs = np.where(X_column > split_thresh)[0]
        return left_idxs, right_idxs

    def _entropy(self, y):
        hist = np.bincount(y) #computing the frequency dist of classes in the y
        ps = hist / len(y)
        entropy = -np.sum([p * np.log2(p) for p in ps if p > 0]) #using entropy formula
        return entropy if not np.isnan(entropy) else 0 # Handle cases where entropy is NaN

    def _most_common_label(self, y):
        counter = {}
        for label in y:
            counter[label] = counter.get(label, 0) + 1
        most_common_label = max(counter, key=counter.get)
        return most_common_label

    def predict(self, X):
        #we will make an array to store the predicted class labels for each sample
        predictions = np.empty(len(X), dtype=int)
        for i, x in enumerate(X):
            #initializing the node variable with the root node of the decision tree
            #This is the starting point for traversing the decision tree for each x
            node = self.root
            
            while not node.is_leaf_node():
                # basically, if the feature value is less than or equal to the thr, 
                #the left child node is selected; otherwise the right child node is selected.
                if x[node.feature] <= node.threshold:
                    node = node.left
                else:
                    node = node.right
            predictions[i] = node.value #leaf node reached,
            #now assign the predicted class label stored in the leaf node (node.value) to the corresponding index i in the predictions array
        return predictions
    
    #Follows the decision tree recursively until reaching a leaf node, returning its predicted value
    def _traverse_tree(self, x, node):
        while node.left and node.right:
            if x[node.feature] <= node.threshold:
                node = node.left
            else:
                node = node.right
        return node.value


# In[4]:


class RandomForest:
    def __init__(self, n_trees=10, min_samples_split=10, max_depth=100, n_features=None):
        self.n_trees = n_trees
        self.min_samples_split = min_samples_split
        self.max_depth = max_depth
        self.n_features = n_features
        self.trees = []

    def fit(self, X, y):
        # Check for NaN values in the input
        if np.isnan(X).any():
            # Handling NaN values - replacing them with mean values
            X = np.nan_to_num(X, nan=np.nanmean(X))
        self.trees = []
        for _ in range(self.n_trees):
            tree = DecisionTree(min_samples_split=self.min_samples_split,
                                max_depth=self.max_depth,
                                n_features=self.n_features)
            #Random indices are sampled with replacement from the range of indices of the training data
            indices = np.random.choice(len(X), len(X), replace=True)
            #bootstrap sample is created using the sampled indices.
            X_bootstrap, y_bootstrap = X[indices], y[indices]
            tree.fit(X_bootstrap, y_bootstrap)
            self.trees.append(tree)

    def predict(self, X):
        predictions = np.array([tree.predict(X) for tree in self.trees])
        return majority_voting(predictions)


# In[5]:


def bootstrap(X_train, y_train, n_trees):
    bootstrap_data = []
    
    for _ in range(n_trees):
        #sampling w replacement from. input data
        sampling = np.random.choice(len(X_train), len(X_train), replace=True)
        #features and labels corresponding to the sampled indices are extracted from the training data and a tuple is created
        X_bootstrap = X_train[sampling]
        y_bootstrap = y_train[sampling]
        
        bootstrap_data.append((X_bootstrap, y_bootstrap))
    return bootstrap_data


# In[6]:


def majority_voting(preds):
    pred_tuples = [tuple(pred) for pred in preds]
    vote_count = Counter(pred_tuples)
    
    # Get the class labels with the maximum count
    max_count = max(vote_count.values())
    max_classes = [cls for cls, count in vote_count.items() if count == max_count]
    
    # If there is no tie, return the class label with the maximum count
    if len(max_classes) == 1:
        return max_classes[0]
    
    # If there is a tie, apply the tie-breaking rule
    tie_breaker = min(max_classes)  # Example: Choose the class with the lowest label
    return tie_breaker


# In[7]:


def stratified_cross_validation(X, y, n_splits, n_trees, max_depth, min_samples_split, n_features):
    k = n_splits
    fold_size = len(X) // k
    accuracies = []
    precisions = []
    f1_scores = []
    recalls = []
    conf_matrices = []

    for i in range(k):
        start_idx = i * fold_size
        end_idx = (i + 1) * fold_size if i < k - 1 else len(X)

        # Initialize fold data structures
        X_train = []
        y_train = []
        X_test = X[start_idx:end_idx]
        y_test = y[start_idx:end_idx]

        # Calculate class proportions in the original dataset
        class_proportions = {cls: np.sum(y == cls) / len(y) for cls in np.unique(y)}

        # Initialize counters for class occurrences in the fold
        class_counts = {cls: 0 for cls in np.unique(y)}

        # Add instances to the fold while maintaining class proportions
        for j in range(start_idx, end_idx):
            cls = y[j]

            # If adding the instance would maintain class proportions, add it
            if class_counts[cls] / (j - start_idx + 1) <= class_proportions[cls]:
                X_train.append(X[j])
                y_train.append(y[j])
                class_counts[cls] += 1

        # Train the random forest model
        rf = RandomForest(n_trees=n_trees, max_depth=max_depth, min_samples_split=min_samples_split,
                          n_features=n_features)
        rf.fit(np.array(X_train), np.array(y_train))

        y_pred_majority = rf.predict(X_test)  # Obtain majority vote predictions

        # Calculate confusion matrix
        conf_matrix = calculate_confusion_matrix(y_test, y_pred_majority, num_classes=len(np.unique(y)))

        # Append confusion matrix
        conf_matrices.append(conf_matrix)

        # Calculate metrics for this split
        accuracy, precision, recall, f1_score = calculate_precision_recall_f1(y_test, y_pred_majority)
        accuracies.append(accuracy)
        precisions.append(precision)
        recalls.append(recall)
        f1_scores.append(f1_score)

    # Calculate average metrics
    avg_accuracy = np.mean(accuracies)
    avg_precision = np.mean(precisions)
    avg_recall = np.mean(recalls)
    avg_f1_score = np.mean(f1_scores)

    # Calculate overall confusion matrix
    overall_conf_matrix = np.sum(conf_matrices, axis=0)

    return avg_accuracy, avg_precision, avg_recall, avg_f1_score, overall_conf_matrix


# In[8]:


def calculate_confusion_matrix(true_labels, predicted_labels, num_classes):
    # Initialize confusion matrix with zeros
    conf_matrix = np.zeros((num_classes, num_classes))
    
    # Iterate over each pair of true and predicted labels
    for true_label, pred_label in zip(true_labels, predicted_labels):
        # Increment the corresponding cell in the confusion matrix
        conf_matrix[true_label - 1][pred_label - 1] += 1  # Assuming class labels start from 1
        
    return conf_matrix


# In[9]:


def calculate_precision_recall_f1(y_test, y_pred_majority):
    # Calculate precision, recall, and F1-score for each class
    classes = np.unique(y_test)
#     accuracies = []
    conf_matrix = np.zeros((len(classes), len(classes)))
    precisions = []
    recalls = []
    f1_scores = []
#     false_positives = []
    for cls in classes:
        TP = np.sum((y_test == cls) & (y_pred_majority == cls))
        FP = np.sum((y_test != cls) & (y_pred_majority == cls))
        FN = np.sum((y_test == cls) & (y_pred_majority != cls))
        TN = np.sum((y_test != cls) & (y_pred_majority != cls))

#         accuracy = TP + TN / (TP + TN + FP + FN) if (TP + FP +TN +FN) > 0 else 0
        precision = TP / (TP + FP) if (TP + FP) > 0 else 0
        recall = TP / (TP + FN) if (TP + FN) > 0 else 0
        f1_score = 2 * (precision * recall) / (precision + recall) if (precision + recall) > 0 else 0
        
#         accuracies.append(accuracy)
        precisions.append(precision)
        recalls.append(recall)
#         false_positives.append(FP)
        f1_scores.append(f1_score)
    total_TP = np.sum(np.equal(y_test, y_pred_majority))
    accuracy = total_TP / len(y_test)

    return accuracy, np.mean(precisions), np.mean(recalls), np.mean(f1_scores)


# In[10]:


# Read the dataset
df = pd.read_csv("/Users/mitalijuvekar/Documents/SEM2/589/final_project/parkinsons.csv")

# Extract features and labels
X = df.iloc[:, :-1].values  # Features (all columns except the last one)
y = df.iloc[:, -1].values   # Labels (last column)

# Parameters
n_splits = 10  # Number of splits for cross-validation
n_trees = [1, 5, 10, 20, 30, 40, 50]  # Different values for the number of trees
max_depth = 100
min_samples_split = 10
n_features = None

# Perform stratified cross-validation for each value of n_trees
for n_tree in n_trees:
    avg_accuracy, avg_precision, avg_recall, avg_f1_score, overall_conf_matrix = stratified_cross_validation(X, y, n_splits, n_tree, max_depth, min_samples_split, n_features)
    print(f"Metrics for {n_tree} trees:")
    print(f"Average Accuracy: {avg_accuracy}")
    print(f"Average Precision: {avg_precision}")
    print(f"Average Recall: {avg_recall}")
    print(f"Average F1 Score: {avg_f1_score}")
    print("Confusion Matrix:")
    print(overall_conf_matrix)


# In[11]:


# Initializing lists to store metric values
accuracy_values = []
precision_values = []
recall_values = []
f1_score_values = []

# Iterating over each value of ntree
for n_tree in n_trees:
    # Performing cross-validation + calculating metrics
    avg_accuracy, avg_precision, avg_recall, avg_f1_score, overall_conf_matrix = stratified_cross_validation(X, y, n_splits, n_tree, max_depth, min_samples_split, n_features)
    
    accuracy_values.append(avg_accuracy)
    precision_values.append(avg_precision)
    recall_values.append(avg_recall)
    f1_score_values.append(avg_f1_score)


# In[12]:


import matplotlib.pyplot as plt

# Initializing lists to store metric values
accuracy_values = []
precision_values = []
recall_values = []
f1_score_values = []

# Iterating over each value of ntree
for n_tree in n_trees:
    # Performing cross-validation + calculating metrics
    avg_accuracy, avg_precision, avg_recall, avg_f1_score, overall_conf_matrix = stratified_cross_validation(X, y, n_splits, n_tree, max_depth, min_samples_split, n_features)
    
    accuracy_values.append(avg_accuracy)
    precision_values.append(avg_precision)
    recall_values.append(avg_recall)
    f1_score_values.append(avg_f1_score)


# Plot the graphs
plt.figure(figsize=(10, 8))

# Plot accuracy
plt.subplot(2, 2, 1)
plt.plot(n_trees, accuracy_values, marker='o')
plt.xlabel('Number of Trees (ntree)')
plt.ylabel('Accuracy')
plt.title('Accuracy vs ntree')

# Plot precision
plt.subplot(2, 2, 2)
plt.plot(n_trees, precision_values, marker='o')
plt.xlabel('Number of Trees (ntree)')
plt.ylabel('Precision')
plt.title('Precision vs ntree')

# Plot recall
plt.subplot(2, 2, 3)
plt.plot(n_trees, recall_values, marker='o')
plt.xlabel('Number of Trees (ntree)')
plt.ylabel('Recall')
plt.title('Recall vs ntree')

# Plot F1 score
plt.subplot(2, 2, 4)
plt.plot(n_trees, f1_score_values, marker='o')
plt.xlabel('Number of Trees (ntree)')
plt.ylabel('F1 Score')
plt.title('F1 Score vs ntree')

# Adjust layout
plt.tight_layout()

# Show the plot
plt.show()


# # Using gini criterion

# In[13]:


class DecisionTree:
    def __init__(self, min_samples_split=10, max_depth=16, n_features=None):
        self.min_samples_split = min_samples_split
        self.max_depth = max_depth
        self.n_features = n_features
        self.root = None

    def fit(self, X, y):
        self.n_features = X.shape[1] if not self.n_features else min(X.shape[1], self.n_features)
        self.root = self._grow_tree(X, y)

    def _grow_tree(self, X, y, depth=0, used_features=None):
        n_samples, n_feats = X.shape
        n_labels = len(set(y)) 

        if (depth >= self.max_depth or n_labels == 1 or n_samples < self.min_samples_split):
            leaf_value = self._most_common_label(y)
            return Node(value=leaf_value)

        feat_idxs = select_random_attributes(n_feats) if used_features is None else [idx for idx in range(n_feats) if idx not in used_features]
        best_feature, best_thresh = self._best_split(X, y, feat_idxs)
        left_idxs, right_idxs = self._split(X[:, best_feature], best_thresh)
        
        if len(left_idxs) == 0 or len(right_idxs) == 0:
            leaf_value = self._most_common_label(y)
            return Node(value=leaf_value)

        left_used_features = set(used_features) if used_features is not None else set()
        right_used_features = set(used_features) if used_features is not None else set()
        left_used_features.add(best_feature)
        right_used_features.add(best_feature)

        left = self._grow_tree(X[left_idxs, :], y[left_idxs], depth + 1, left_used_features)
        right = self._grow_tree(X[right_idxs, :], y[right_idxs], depth + 1, right_used_features)
        return Node(best_feature, best_thresh, left, right)

    def _random_features(self, n_feats):
        if self.n_features is None:
            return np.arange(n_feats)
        else:
            return np.random.choice(n_feats, self.n_features, replace=False)
    
    def _best_split(self, X, y, feat_idxs):
        best_gini = float('inf')
        split_idx, split_threshold = None, None

        for feat_idx in feat_idxs:
            X_column = X[:, feat_idx]
            thresholds = np.unique(X_column)

            for thr in thresholds:
                gini = self._gini_impurity(y, X_column, thr)

                if gini < best_gini:
                    best_gini = gini
                    split_idx = feat_idx
                    split_threshold = thr

        return split_idx, split_threshold

    def _gini_impurity(self, y, X_column, threshold):
        # Create children
        left_idxs, right_idxs = self._split(X_column, threshold)

        if len(left_idxs) == 0 or len(right_idxs) == 0:
            return 1  # Maximum impurity if one of the children is empty

        # Calculate the weighted Gini impurity of children
        n = len(y)
        n_l, n_r = len(left_idxs), len(right_idxs)
        gini_l = self._gini(y[left_idxs])
        gini_r = self._gini(y[right_idxs])
        weighted_gini = (n_l / n) * gini_l + (n_r / n) * gini_r

        return weighted_gini

    def _gini(self, y):
        hist = np.bincount(y)
        ps = hist / len(y)
        gini = 1 - np.sum(ps ** 2)
        return gini

    def _split(self, X_column, split_thresh):
        left_idxs = np.where(X_column <= split_thresh)[0]
        right_idxs = np.where(X_column > split_thresh)[0]
        return left_idxs, right_idxs

    def _entropy(self, y):
        hist = np.bincount(y)
        ps = hist / len(y)
        entropy = -np.sum([p * np.log2(p) for p in ps if p > 0])
        return entropy if not np.isnan(entropy) else 0

    def _most_common_label(self, y):
        counter = Counter(y)
        most_common_label = counter.most_common(1)[0][0]
        return most_common_label

    def predict(self, X):
        predictions = []
        for x in X:
            predictions.append(self._traverse_tree(x, self.root))
        return np.array(predictions)

    def _traverse_tree(self, x, node):
        while node.left and node.right:
            if x[node.feature] <= node.threshold:
                node = node.left
            else:
                node = node.right
        return node.value


# In[14]:


# Read the dataset
df = pd.read_csv("/Users/mitalijuvekar/Documents/SEM2/589/final_project/parkinsons.csv")

# Extract features and labels
X = df.iloc[:, :-1].values  # Features (all columns except the last one)
y = df.iloc[:, -1].values   # Labels (last column)

# Parameters
n_splits = 10  # Number of splits for cross-validation
n_trees = [1, 5, 10, 20, 30, 40, 50]  # Different values for the number of trees
max_depth = 100
min_samples_split = 10
n_features = None

# Perform stratified cross-validation for each value of n_trees
for n_tree in n_trees:
    avg_accuracy, avg_precision, avg_recall, avg_f1_score, overall_conf_matrix = stratified_cross_validation(X, y, n_splits, n_tree, max_depth, min_samples_split, n_features)
    print(f"Metrics for {n_tree} trees:")
    print(f"Average Accuracy: {avg_accuracy}")
    print(f"Average Precision: {avg_precision}")
    print(f"Average Recall: {avg_recall}")
    print(f"Average F1 Score: {avg_f1_score}")
    print("Confusion Matrix:")
    print(overall_conf_matrix)


# In[15]:


# Initializing lists to store metric values
accuracy_values = []
precision_values = []
recall_values = []
f1_score_values = []

# Iterating over each value of ntree
for n_tree in n_trees:
    # Performing cross-validation + calculating metrics
    avg_accuracy, avg_precision, avg_recall, avg_f1_score, overall_conf_matrix = stratified_cross_validation(X, y, n_splits, n_tree, max_depth, min_samples_split, n_features)
    
    accuracy_values.append(avg_accuracy)
    precision_values.append(avg_precision)
    recall_values.append(avg_recall)
    f1_score_values.append(avg_f1_score)


# In[16]:


import matplotlib.pyplot as plt

# Initializing lists to store metric values
accuracy_values = []
precision_values = []
recall_values = []
f1_score_values = []

# Iterating over each value of ntree
for n_tree in n_trees:
    # Performing cross-validation + calculating metrics
    avg_accuracy, avg_precision, avg_recall, avg_f1_score, overall_conf_matrix = stratified_cross_validation(X, y, n_splits, n_tree, max_depth, min_samples_split, n_features)
    
    accuracy_values.append(avg_accuracy)
    precision_values.append(avg_precision)
    recall_values.append(avg_recall)
    f1_score_values.append(avg_f1_score)


# Plot the graphs
plt.figure(figsize=(10, 8))

# Plot accuracy
plt.subplot(2, 2, 1)
plt.plot(n_trees, accuracy_values, marker='o')
plt.xlabel('Number of Trees (ntree)')
plt.ylabel('Accuracy')
plt.title('Accuracy vs ntree')

# Plot precision
plt.subplot(2, 2, 2)
plt.plot(n_trees, precision_values, marker='o')
plt.xlabel('Number of Trees (ntree)')
plt.ylabel('Precision')
plt.title('Precision vs ntree')

# Plot recall
plt.subplot(2, 2, 3)
plt.plot(n_trees, recall_values, marker='o')
plt.xlabel('Number of Trees (ntree)')
plt.ylabel('Recall')
plt.title('Recall vs ntree')

# Plot F1 score
plt.subplot(2, 2, 4)
plt.plot(n_trees, f1_score_values, marker='o')
plt.xlabel('Number of Trees (ntree)')
plt.ylabel('F1 Score')
plt.title('F1 Score vs ntree')

# Adjust layout
plt.tight_layout()

# Show the plot
plt.show()


# In[ ]:




