#!/usr/bin/env python
# coding: utf-8

# In[1]:


from sklearn import datasets
import numpy as np
import matplotlib.pyplot as plt


# In[2]:


digits = datasets.load_digits (return_X_y=True )


# In[3]:


digits_dataset_X = digits[0]


# In[4]:


digits


# In[5]:


digits_dataset_X


# In[6]:


digits_dataset_y = digits[1]


# In[7]:


digits_dataset_y


# In[8]:


N = len(digits_dataset_X)


# In[9]:


N


# In[10]:


unique_labels = np.unique(digits_dataset_y)
print(unique_labels)


# In[11]:


#import dependencies
import pandas as pd
import numpy as np
from collections import Counter
import matplotlib.pyplot as plt


class Node:
    def __init__(self, feature=None, threshold=None, left=None, right=None, *, value=None):
        self.feature = feature #the actual attribute used for splitting at this node
        self.threshold = threshold #we need this because we need to know when to split the numerical features 
        self.left = left #left child 
        self.right = right #right child
        self.value = value #class label BUT ONLY if the node is a leaf node

    def is_leaf_node(self): #to check if current node has no children
        return self.value is not None


# In[12]:


class DecisionTree:
    def __init__(self, min_samples_split=2, max_depth=100, n_features=None):
        self.min_samples_split = min_samples_split
        self.max_depth = max_depth
        self.n_features = n_features
        self.root = None

    def fit(self, X, y):
        self.n_features = X.shape[1] if not self.n_features else min(X.shape[1], self.n_features)
        self.root = self._grow_tree(X, y, depth=0)

    def _grow_tree(self, X, y, depth=0):
        n_samples, n_feats = X.shape
        n_labels = len(set(y)) 

        if (depth >= self.max_depth or n_labels == 1 or n_samples < self.min_samples_split): #Checks if the current depth of 
            #the tree has reached the maximum allowed depth. OR if there is only one unique label remaining in y.
            leaf_value = self._most_common_label(y)
            return Node(value=leaf_value)

        feat_idxs = self._random_features(n_feats)   #selecting indexes of features randomly

        best_feature, best_thresh = self._best_split(X, y, feat_idxs)
        left_idxs, right_idxs = self._split(X[:, best_feature], best_thresh) #splits the dataset into two subsets based on a selected feature and its threshold value, 
        #assigning the indices of samples to the left and right subsets. 
        #need to do this because need to enable recursive partitioning of the data.

        left = self._grow_tree(X[left_idxs, :], y[left_idxs], depth + 1)
        right = self._grow_tree(X[right_idxs, :], y[right_idxs], depth + 1)
        return Node(best_feature, best_thresh, left, right)
    
    #randomly selects a subset of features from the total available features based on specified number of features
    def _random_features(self, n_feats):
        if self.n_features is None:
            return np.arange(n_feats)
        else:
            return np.random.choice(n_feats, self.n_features, replace=False)
    
    def _best_split(self, X, y, feat_idxs): #we'll iterate thru selected features
        best_gain = -1
        split_idx, split_threshold = None, None

        for feat_idx in feat_idxs:
            X_column = X[:, feat_idx] #X_column holds the values of a specific feature being iterated thru currently
            thresholds = np.unique(X_column) #calculating the unique values present in that feature, use this as threshold baadmein

            for thr in thresholds:
                # calculate the information gain
                gain = self._information_gain(y, X_column, thr)

                if gain > best_gain:
                    best_gain = gain
                    split_idx = feat_idx
                    split_threshold = thr

        return split_idx, split_threshold

    def _information_gain(self, y, X_column, threshold):
        # parent entropy
        parent_entropy = self._entropy(y)

        # create children
        left_idxs, right_idxs = self._split(X_column, threshold)

        if len(left_idxs) == 0 or len(right_idxs) == 0:
            return 0

        # calculating the weighted avg entropy of children #need to measure impurity at each split
        n = len(y)
        n_l, n_r = len(left_idxs), len(right_idxs)
        #all these calcs for info gain
        e_l = self._entropy(y[left_idxs])
        e_r = self._entropy(y[right_idxs])
        child_entropy = (n_l / n) * e_l + (n_r / n) * e_r

        # calculate the IG
        information_gain = parent_entropy - child_entropy

        if parent_entropy == 0:  # need to handle the case where parent entropy is 0
            return 0

        return information_gain if not np.isnan(information_gain) else 0  # Handle cases where IG is NaN


    def _split(self, X_column, split_thresh):
        left_idxs = [idx for idx, val in enumerate(X_column) if val <= split_thresh]
        right_idxs = [idx for idx, val in enumerate(X_column) if val > split_thresh]
        return left_idxs, right_idxs

    def _entropy(self, y):
        hist = np.bincount(y) #computing the frequency dist of classes in the y
        ps = hist / len(y)
        entropy = -np.sum([p * np.log(p) for p in ps if p > 0]) #using formula
        return entropy if not np.isnan(entropy) else 0  # Handle cases where entropy is NaN

    def _most_common_label(self, y):
        counter = {}
        for label in y:
            counter[label] = counter.get(label, 0) + 1
        most_common_label = max(counter, key=counter.get)
        return most_common_label

    def predict(self, X):
        predictions = []
        for x in X:
            predictions.append(self._traverse_tree(x, self.root))
        return np.array(predictions)
    
    #Follows the decision tree recursively until reaching a leaf node, returning its predicted value
    def _traverse_tree(self, x, node):
        while node.left and node.right:
            if x[node.feature] <= node.threshold:
                node = node.left
            else:
                node = node.right
        return node.value


# In[13]:


# Function to perform the experiment
def perform_experiment(X, y, n_iterations, max_depth, min_samples_split, n_features):
    train_accuracies = []
    test_accuracies = []

    for _ in range(n_iterations):
        indices = np.random.permutation(len(X)) 

        train_size = int(len(X) * 0.8)
        train_indices, test_indices = indices[:train_size], indices[train_size:]

        X_train, y_train = X[train_indices], y[train_indices]
        X_test, y_test = X[test_indices], y[test_indices]

        clf = DecisionTree(min_samples_split=min_samples_split, max_depth=max_depth, n_features=n_features)
        clf.fit(X_train, y_train)

        train_pred = clf.predict(X_train)
        train_accuracy = (train_pred == y_train).mean()
        train_accuracies.append(train_accuracy)

        test_pred = clf.predict(X_test)
        test_accuracy = (test_pred == y_test).mean()
        test_accuracies.append(test_accuracy)

    return train_accuracies, test_accuracies


# In[14]:


y = digits_dataset_y  # Labels
X = digits_dataset_X  # Attributes


# In[15]:


# Parameters
n_iterations = 100
max_depth = 100
min_samples_split = 2
n_features = None  # If None, all features will be considered at each split


# In[18]:


# Perform experiment
train_accuracies, test_accuracies = perform_experiment(X, y, n_iterations, max_depth, min_samples_split, n_features)

# Calculate and print average and standard deviation
avg_train_accuracy = np.mean(train_accuracies)
std_train_accuracy = np.std(train_accuracies)

avg_test_accuracy = np.mean(test_accuracies)
std_test_accuracy = np.std(test_accuracies)


# In[19]:


print(f"Average Training Set Accuracy: {avg_train_accuracy:.4f}")
print(f"Standard Deviation Training Set Accuracy: {std_train_accuracy:.4f}")
print(f"Average Testing Set Accuracy: {avg_test_accuracy:.4f}")
print(f"Standard Deviation Testing Set Accuracy: {std_test_accuracy:.4f}")


# In[20]:


# Plot histograms
plt.figure(figsize=(12, 6))

plt.subplot(1, 2, 1)
plt.hist(train_accuracies, bins=20, color='blue', edgecolor='black')
plt.title('Training Set Accuracy Distribution')
plt.xlabel('Accuracy')
plt.ylabel('Frequency')

plt.subplot(1, 2, 2)
plt.hist(test_accuracies, bins=20, color='green', edgecolor='black')
plt.title('Testing Set Accuracy Distribution')
plt.xlabel('Accuracy')
plt.ylabel('Frequency')

plt.tight_layout()
plt.show()


# In[ ]:




